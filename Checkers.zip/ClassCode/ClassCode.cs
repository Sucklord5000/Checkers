﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassCode
{
    public class ClassCode
    {
        public enum Commands
        {
             GetMyField
        };
        public Commands Command { get; set; }
    }
}
