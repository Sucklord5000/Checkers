﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Checkers
{
    class Cell
    {
        public Brush Color { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public Checker Checker { get; set; }
    }
}
