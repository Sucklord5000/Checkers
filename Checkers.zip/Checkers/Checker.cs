﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Checkers
{
    class Checker : AbstractChecker
    {
        public Brush Color { get; set; }
    }
}
