﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Handler
    {
        private List<Client> Clients;
        private TcpListener Listener;
        public Handler()
        {
            this.Clients = new List<Client>();
            IPAddress adress = IPAddress.Parse("127.0.0.1");
            this.Listener = new TcpListener(adress, 8888);
            this.Listener.Start();
            new Thread(Start).Start();
        }
        private async void Start()
        {
            while (true)
            {
                TcpClient client = await this.Listener.AcceptTcpClientAsync();
                this.Clients.Add(new Client()
                {
                    Clients = client,
                    ID = this.Clients.Count + 1,
                    Stream = client.GetStream()
                });
                ThreadPool.QueueUserWorkItem(x => Start());
            }
        }
        private async void AwaitCode(Client client)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                while (true)
                {
                    byte[] data = new byte[client.Clients.ReceiveBufferSize];
                    await client.Stream.ReadAsync(data, 0, data.Length);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        var obj = (ClassCode.ClassCode)formatter.Deserialize(stream);
                        switch (obj.Command)
                        {
                            case ClassCode.ClassCode.Commands.GetMyField:

                                break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                client.Clients.Close();
                this.Clients.Remove(client);
            }
        }
    }
}
