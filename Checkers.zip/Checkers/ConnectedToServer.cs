﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Checkers
{
    class ConnectedToServer
    {
        private TcpClient Client;
        private NetworkStream Stream;
        public ConnectedToServer()
        {
            this.Client = new TcpClient();
            this.Client.ConnectAsync("127.0.0.1", 8888);
            this.Stream = this.Client.GetStream();
        }
    }
}
