﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    class Client
    {
        public TcpClient Clients { get; set; }
        public NetworkStream Stream { get; set; }
        public int ID { get; set; }

    }
}
