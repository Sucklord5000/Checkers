﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Checkers
{
    class Board
    {
        private Cell[,] ChessBoard;
        private const Int32 Column = 10;
        private const Int32 Row = 10;
        private OldPosition Position;
        private Boolean ClickToButton = true;
        public Board()
        {
            this.ChessBoard = new Cell[Row, Column];
            this.Position = new OldPosition();
            GeneratedField();
        }
        private void GeneratedField()
        {
            bool Flag = true;
            for (int x = 0; x < Row; x++)
            {
                for (int y = 0; y < Column; y++)
                {
                    Button button = new Button();
                    button.BorderThickness = new Thickness(0);
                    if (Flag)
                    {
                        this.ChessBoard[x, y] = new Cell
                        {
                            X = x,
                            Y = y,
                            Color = Brushes.SaddleBrown
                        };
                        button.Background = this.ChessBoard[x, y].Color;
                        Flag = false;
                    }
                    else
                    {
                        if (x < 4)
                        {
                            Ellipse ellipse = new Ellipse();
                            ellipse.Width = 30;
                            ellipse.Height = 30;
                            ellipse.Fill = Brushes.White;
                            button.Content = ellipse;
                            this.ChessBoard[x, y] = new Cell
                            {
                                Checker = new Checker
                                {
                                    Color = Brushes.White,
                                    King = false
                                },
                                X = x,
                                Y = y,
                                Color = Brushes.Black
                            };
                            button.Background = this.ChessBoard[x, y].Color;
                        }
                        else if (x > 5)
                        {
                            Ellipse ellipse = new Ellipse();
                            ellipse.Width = 30;
                            ellipse.Height = 30;
                            ellipse.Fill = Brushes.SaddleBrown;
                            button.Content = ellipse;
                            this.ChessBoard[x, y] = new Cell
                            {
                                Checker = new Checker
                                {
                                    Color = Brushes.White,
                                    King = false
                                },
                                X = x,
                                Y = y,
                                Color = Brushes.Black
                            };
                            button.Background = this.ChessBoard[x, y].Color;
                        }
                        else
                        {
                            this.ChessBoard[x, y] = new Cell
                            {
                                X = x,
                                Y = y,
                                Color = Brushes.Black
                            };
                            button.Background = this.ChessBoard[x, y].Color;
                        }

                        button.Click += Click;
                        Flag = true;
                    }
                    
                    Grid.SetColumn(button, y);
                    Grid.SetRow(button, x);
                    App.Grid.Children.Add(button);

                }
                Flag = !Flag;
            }
        }
        private void Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (this.ClickToButton && button.Content != null)
            {
                this.Position.OldX = Grid.GetRow(button);
                this.Position.OldY = Grid.GetColumn(button);
                this.Position.SelectedChecker = (button.Content as Ellipse).Fill;
                this.ClickToButton = false;
            }
            else
            {
                if (CheckStep(Grid.GetRow(button)))
                {
                    if (button.Content == null)
                    {
                        (App.Grid.Children[this.Position.OldX * Row + this.Position.OldY] as Button).Content = null;
                        this.ChessBoard[this.Position.OldX, this.Position.OldY].Checker = null;

                        button.Content = new Ellipse()
                        {
                            Width = 30,
                            Height = 30,
                            Fill = this.Position.SelectedChecker
                        };

                        if (this.ChessBoard[Grid.GetRow(button), Grid.GetColumn(button)].Checker != null)
                            this.ChessBoard[Grid.GetRow(button), Grid.GetColumn(button)].Checker.Color = this.Position.SelectedChecker;
                        else
                        {
                            this.ChessBoard[Grid.GetRow(button), Grid.GetColumn(button)].Checker = new Checker
                            {
                                Color = this.Position.SelectedChecker
                            };
                        }
                    }
                }
                this.ClickToButton = true;
            }
        }
        private bool CheckStep(int X)
        {
            int Row = 0;
            if (this.Position.OldX - 1 == X)
                Row = X;
            else
                return false;

            for (int b = 0; b < this.ChessBoard.GetLength(1); b++)
                if (this.ChessBoard[Row, b].Checker == null && this.ChessBoard[Row, b].Color == Brushes.Black)
                    return true;

            return false;
        }
    }
}
